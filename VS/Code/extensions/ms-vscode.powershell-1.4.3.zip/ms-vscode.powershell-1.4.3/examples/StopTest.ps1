. ./Stop-Process2.ps1

notepad.exe
notepad.exe
notepad.exe

Stop-Process2 -Name "notepad"