## `modules` folder README

This folder contains modules that are bundled with the vscode-powershell extension.
All subfolders are not included in our GitHub repository, they are added here just
before the module is published to the Visual Studio Marketplace.

This file serves as a placeholder so that the `modules` folder will be included
in our Git repository.